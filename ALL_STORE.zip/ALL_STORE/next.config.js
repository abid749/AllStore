/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Bisa ditambah konfigurasi lain sesuai kebutuhan
};

module.exports = nextConfig;