# All Store Hosting

Website hosting Minecraft dengan fitur:

- Pembelian paket hosting Java, domain, unlock port manual
- Dashboard user dan admin
- Sistem pembayaran manual via Dana
- User roles: owner, admin, user
- Penanganan order, produk, dan user management

## Instalasi

1. Clone repo ini
2. Jalankan `npm install`
3. Jalankan `npm run dev` untuk mode development
4. Akses di http://localhost:3000

## Struktur Folder

- `components/` — UI components reusable
- `pages/` — Halaman website
- `services/` — Logika API dan data
- `data/` — Simulasi database lokal
- `utils/` — Helper dan konstanta
- `styles/` — CSS global dan modul

## Catatan

- Pembayaran QRIS belum diimplementasikan
- Sistem unlock port manual untuk admin dan user
- Domain masih dalam tahap pengembangan

---

Kontak: abidaqilalatif24@gmail.com