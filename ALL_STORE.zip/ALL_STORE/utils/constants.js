export const USER_ROLES = {
  OWNER: 'owner',
  ADMIN: 'admin',
  USER: 'user',
};

export const ORDER_STATUS = {
  PENDING: 'pending',
  PAID: 'paid',
  CANCELLED: 'cancelled',
  COMPLETED: 'completed',
};