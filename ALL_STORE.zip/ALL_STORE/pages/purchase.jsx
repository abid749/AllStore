import { useState, useEffect } from 'react';
import { getProducts } from '../services/productService';
import { createOrder } from '../services/orderService';
import { getCurrentUser } from '../services/authService';

export default function PurchasePage() {
  const [products, setProducts] = useState([]);
  const [selectedProduct, setSelectedProduct] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    async function fetchProducts() {
      const prods = await getProducts();
      setProducts(prods);
      if (prods.length > 0) setSelectedProduct(prods[0].id);
    }
    fetchProducts();
  }, []);

  const handlePurchase = async () => {
    if (!selectedProduct) return setMessage('Please select a product');
    setLoading(true);
    const user = await getCurrentUser();
    if (!user) {
      setMessage('Please login first');
      setLoading(false);
      return;
    }
    const result = await createOrder(user.id, selectedProduct);
    setLoading(false);
    if (result.success) {
      setMessage('Order created! Proceed to payment.');
    } else {
      setMessage(result.message || 'Failed to create order');
    }
  };

  return (
    <div className="max-w-lg mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">Purchase Product</h1>
      <select
        value={selectedProduct}
        onChange={(e) => setSelectedProduct(e.target.value)}
        className="border p-2 rounded w-full mb-4"
      >
        {products.map((prod) => (
          <option key={prod.id} value={prod.id}>
            {prod.name} - Rp{prod.price}
          </option>
        ))}
      </select>
      <button
        onClick={handlePurchase}
        disabled={loading}
        className="bg-purple-600 text-white py-2 px-4 rounded hover:bg-purple-700"
      >
        {loading ? 'Processing...' : 'Purchase'}
      </button>
      {message && <p className="mt-4 text-red-600">{message}</p>}
    </div>
  );
}