import { useEffect, useState } from 'react';
import { getAllProducts } from '../services/productService';
import PricingTable from '../components/PricingTable';

export default function ProductsPage() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      const data = await getAllProducts();
      setProducts(data);
      setLoading(false);
    };
    fetchProducts();
  }, []);

  if (loading) {
    return (
      <div className="text-center py-20">
        <p>Loading products...</p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-8">Available Hosting & Domain Packages</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {products.map((product) => (
          <PricingTable key={product.id} product={product} />
        ))}
      </div>
    </div>
  );
}