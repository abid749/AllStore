import { useEffect, useState } from 'react';
import { getAllUsers } from '../services/userService';
import { getAllOrders } from '../services/orderService';
import { getAllProducts } from '../services/productService';
import Notification from '../components/Notification';

export default function AdminPage() {
  const [users, setUsers] = useState([]);
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAdminData = async () => {
      setLoading(true);
      const fetchedUsers = await getAllUsers();
      const fetchedOrders = await getAllOrders();
      const fetchedProducts = await getAllProducts();
      setUsers(fetchedUsers);
      setOrders(fetchedOrders);
      setProducts(fetchedProducts);
      setLoading(false);
    };
    fetchAdminData();
  }, []);

  if (loading) {
    return (
      <div className="text-center py-20">
        <p className="text-gray-600">Loading admin dashboard...</p>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Admin Dashboard</h1>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-2">Users</h2>
        <ul className="list-disc pl-5">
          {users.map((user) => (
            <li key={user.email}>
              {user.email} - Role: {user.role}
            </li>
          ))}
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-2">Orders</h2>
        <ul className="list-disc pl-5">
          {orders.map((order) => (
            <li key={order.id}>
              Order #{order.id} - Product: {order.productName} - Status: {order.status}
            </li>
          ))}
        </ul>
      </section>

      <section className="mb-8">
        <h2 className="text-xl font-semibold mb-2">Products</h2>
        <ul className="list-disc pl-5">
          {products.map((product) => (
            <li key={product.id}>
              {product.name} - Price: Rp{product.price.toLocaleString()}
            </li>
          ))}
        </ul>
      </section>

      <Notification message="Admin can manage users, orders, and products here." />
    </div>
  );
}