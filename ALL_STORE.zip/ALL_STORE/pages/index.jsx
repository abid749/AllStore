import Header from "../components/Header"; import Footer from "../components/Footer"; import PricingTable from "../components/PricingTable"; import DomainList from "../components/DomainList";

export default function HomePage() { return ( <> <Header /> <main className="p-4"> <section> <h1 className="text-3xl font-bold mb-4">Selamat Datang di AllStore</h1> <p className="mb-6">Beli hosting Minecraft, domain, dan layanan lainnya dengan mudah.</p> </section> <PricingTable /> <DomainList /> </main> <Footer /> </> ); }

