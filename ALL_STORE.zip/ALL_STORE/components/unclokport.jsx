import React, { useState } from 'react';

export default function UnlockPort({ onUnlock }) {
  const [port, setPort] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = e => {
    e.preventDefault();
    if (!port) {
      setMessage('Please enter a port number');
      return;
    }
    onUnlock(port);
    setMessage('Port unlock request sent.');
    setPort('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <label>
        Enter port to unlock:
        <input
          type="number"
          value={port}
          onChange={e => setPort(e.target.value)}
          placeholder="e.g. 25565"
          min="1"
          max="65535"
          required
        />
      </label>
      <button type="submit">Unlock Port</button>
      {message && <p>{message}</p>}

      <style jsx>{`
        form {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
          max-width: 300px;
        }
        input {
          padding: 0.5rem;
          font-size: 1rem;
        }
        button {
          padding: 0.5rem;
          font-size: 1rem;
          cursor: pointer;
        }
        p {
          color: green;
          margin-top: 0.5rem;
        }
      `}</style>
    </form>
  );
}