import React from 'react';
import Link from 'next/link';

export default function Header({ user, onLogout }) {
  return (
    <header>
      <nav>
        <Link href="/">Home</Link> | 
        {user ? (
          <>
            <Link href="/dashboard">Dashboard</Link> | 
            <Link href="/profile">Profile</Link> | 
            <button onClick={onLogout}>Logout</button>
          </>
        ) : (
          <>
            <Link href="/login">Login</Link> | 
            <Link href="/register">Register</Link>
          </>
        )}
      </nav>
      <style jsx>{`
        header { padding: 1rem; background: #222; color: white; }
        nav a { margin-right: 10px; color: white; text-decoration: none; }
        button { background: transparent; border: none; color: white; cursor: pointer; }
      `}</style>
    </header>
  );
}