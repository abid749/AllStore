// Simple auth simulation (replace with real auth logic)
import usersData from '../data/users.json';

export function login(email, password) {
  // Cari user berdasarkan email dan password (hashing di real app)
  const user = usersData.find(u => u.email === email && u.password === password);
  if (!user) throw new Error('Invalid email or password');
  // Return user tanpa password
  const { password: _, ...userData } = user;
  return userData;
}

export function register(name, email, password) {
  // Cek email sudah ada belum
  const exists = usersData.some(u => u.email === email);
  if (exists) throw new Error('Email already registered');
  // Buat user baru (ID auto-generate)
  const newUser = {
    id: (usersData.length + 1).toString(),
    name,
    email,
    password, // Simpan langsung (hash di real app)
    role: 'user',
    products: [],
    unlockedPorts: []
  };
  usersData.push(newUser);
  return newUser;
}