import usersData from '../data/users.json';

export function isPortUnlocked(userId, port) {
  const user = usersData.find(u => u.id === userId);
  return user?.unlockedPorts.includes(port) || false;
}

export function unlockPort(userId, port) {
  const user = usersData.find(u => u.id === userId);
  if (!user) throw new Error('User not found');
  if (!user.unlockedPorts.includes(port)) {
    user.unlockedPorts.push(port);
  }
  return user;
}